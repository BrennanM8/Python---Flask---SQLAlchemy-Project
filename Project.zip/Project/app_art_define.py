from sqlalchemy import create_engine
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy import Column, Integer, String, ForeignKey
from sqlalchemy.orm import sessionmaker
from sqlalchemy.orm import relationship
#from sqlalchemy import func

engine = create_engine('sqlite:///art.db')
#engine = create_engine('sqlite:///')
Base = declarative_base()

#####################################################################
# class to make an Author
class Author(Base):
   __tablename__ = 'authors'
   
   id = Column(Integer, primary_key=True)
   lastName = Column(String)
   firstName = Column(String)
   country = Column(String)
   birthDate = Column(String)  # I've seen such old dates cause issues so I will stick to strings for now
   deathDate = Column(String)
   wrote = relationship("Books")
   books = relationship("Books") # note relationship added to imports above
   
#######################################################################
# class to make a Painting 
# we assume a painting was made by ONE painter   
class Books(Base):
   __tablename__ = 'books'
   
   id = Column(Integer, primary_key=True)
   title = Column(String)
   painter_id = Column(Integer, ForeignKey('authors.id'))
   # note: ForeignKey added to imports above
   # the argument of ForeignKey is a table.column  
   # note it's table name not class name

   # Hard-coded artist data 

Base.metadata.create_all(engine)




