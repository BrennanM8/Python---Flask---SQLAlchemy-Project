# Defining a form for entering data to insert an artist 
# into our art database

from flask_wtf import FlaskForm
from wtforms import SubmitField, StringField
from wtforms.fields import choices
from wtforms.fields.choices import SelectField
from wtforms.validators import InputRequired, Length

# Class for inserting an artist 
class Artist_Form(FlaskForm):

   id = SelectField("Forgein Key")
   choices=("1","The Ickabog"),("2","Harry Potter and the Socerers Stone"),("3", "The Cuckoo's Calling"), ("4", "IT"), ("5", "The Shining"), ("6", "Carrie")

   lastName = StringField("last name", 
   validators=[InputRequired(message="You must enter a last name"), 
   Length(min=2, max=60, message="Last Name length must be between 2 and 60 characters")])

   # for now we are requiring first and last name but that can cause issues  
   firstName = StringField("first name", 
   validators=[InputRequired(message="You must enter a first name"), 
   Length(min=2, max=60, message="First Name length must be between 2 and 60 characters")])
   
   country = StringField("Country", 
   validators=[InputRequired(message="You must enter a country"), 
   Length(min=2, max=60, message="Country length must be between 2 and 60 characters")])

   birthDate = StringField("Birth Date")

   deathDate = StringField("Death Date")
     
   submit = SubmitField("Insert Author")