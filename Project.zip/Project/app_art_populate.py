import app_art_define as my_db
from sqlalchemy.orm import sessionmaker

Session = sessionmaker(bind=my_db.engine)
session = Session()


import json
import os
os.chdir(os.path.dirname(os.path.realpath(__file__)))

with open('static/data/project.json') as f:
   art = json.load(f)


for i, artist in enumerate(art["authors"]):
   # print("{} -- {} {}".format(i, artist["firstName"], artist["lastName"]))
   a_painter = my_db.Painter(lastName=artist["lastName"], firstName=artist["firstName"], 
   country=artist["countryName"], birthDate=artist["birthDate"], 
   deathDate=artist["deathDate"]) 
   session.add(a_painter)
   session.flush()  
      
   
   for j, painting in enumerate(art["authors"][i]["books"]):
      # print("\t", chr(97+j), art["painters"][i]["paintings"][j]["title"])
      a_painting = my_db.Painting(title=painting["title"], id=painting["id"])
      a_painting.painter_id = a_painter.id
      session.add(a_painting)

session.commit()

######################################################################################################

# query the author table - Query for the 1 table for authors
print("\n\nAuthor Query\n")
query = session.query(my_db.Author).filter(my_db.Author.id==1)
item = query.first()
print ("id={} {}, {} from {}".format(item.id, item.lastName, item.firstName, item.country )) 

# Query the author table and the amount of bookse each authpr wrote - Two related tables
print("\n\nNumber of books for each author\n")
artists = session.query(my_db.Author).all()
for artist in artists:
   print("{} {} has {} works in the database".format(artist.firstName, 
   artist.lastName, len(artist.books)))

# Query the results to a Data Table 
query = session.query(art)
results = query.all()
for item in results:
   print ("id={} lastName={} firstName={} birthDate={}".format(item.id, item.lastName, item.firstName, item.birthDate )) 

# Not really sure how to Query to a HTML table.....
