import app_art_define as my_db
from sqlalchemy.orm import sessionmaker

Session = sessionmaker(bind=my_db.engine)
session = Session()

from forms_art import Artist_Form

from flask import Flask, render_template, url_for, request, redirect
app = Flask(__name__)


app.config["SECRET_KEY"]='why_a_duck?'


@app.route("/")
def myredirect():
   return redirect(url_for('artist_form'))

###################################################################
# route for inserting an artist
@app.route('/artist_form', methods=['GET', 'POST'])
def artist_form():
   form = Artist_Form()

  
   if form.validate_on_submit():
      result = request.form
      a_painter = my_db.Painter(id= result["id"],lastName= result["lastName"], firstName=result["firstName"], country = result["country"], birthDate=result["birthDate"], deathDate=result["deathDate"])
      session.add(a_painter)
      session.commit()  

      return render_template('artist_form_handler.html', title="Insert Book and Author Form Handler", header="Insert Book and Author Form handler", result=result)
   return render_template('artist_form.html', title="Book and Author Project", header="Insert Book and Author Form", form=form)



## Attempting to add another route....

##@app.route('/books_form', methods=['GET', 'POST'])
##def books_form():
   #form = Books_Form(from_other=author_choices)
   ##form = books_Form()
   ##form.painter_id.choices=author_choices
   #form.painter_id.choices=[(1, "Jk"), (2, "Stephan") ]
  ## print(form.validate_on_submit())
   # KEPT COMING BACK AS INVALID
  ## if form.validate_on_submit():
   #if form.is_submitted():
     ## result = request.form
      
     ## a_books = my_db.Painting(title= result["title"])
     ## a_books.painter_id = result["painter_id"]
    ##  session.add(a_painting)
     ## session.commit() 
   
     ## return render_template('painting_form_handler.html', title="Books Form Form Handler", header="Books Form Form handler", result=result)

   ##return render_template('painting_form.html', title=" Books Form", header="Books Form Form", form=form)


##if __name__ == "__main__":
  ## app.run(debug=True)